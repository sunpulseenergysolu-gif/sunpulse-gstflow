// GSTFlow Client-Side Application Engine
let stateCodes = [];
let companyProfile = {};
let allInvoices = [];
let allPurchases = [];
let allParties = [];
let allItems = [];
let currentInvoiceData = null;

// Multi-User RBAC State
let currentUserRole = "ADMIN";
let currentUsername = "admin";
let currentUserDisplayName = "Business Owner / Admin";

// Initialization
document.addEventListener("DOMContentLoaded", async () => {
  initLockClock();
  applyUserRolePermissions();
  await loadStateCodes();
  initPeriodFilters();
  await loadDashboardData();
  await loadParties();
  await loadItems();
  
  const today = new Date().toISOString().split("T")[0];
  if (document.getElementById("invDate")) document.getElementById("invDate").value = today;
  if (document.getElementById("billDate")) document.getElementById("billDate").value = today;

  onReportsPeriodChange();
  lucide.createIcons();
});

function initPeriodFilters() {
  const today = new Date().toISOString().split("T")[0];
  const currentFy = getFinancialYear(today) || "2026-27";
  const currentMonth = getMonthCode(today) || "09";

  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val;
  };

  setVal("dashFyFilter", currentFy);
  setVal("dashMonthFilter", currentMonth);
  setVal("salesFyFilter", currentFy);
  setVal("salesMonthFilter", currentMonth);
  setVal("purchasesFyFilter", currentFy);
  setVal("purchasesMonthFilter", currentMonth);
  setVal("reportsFyFilter", currentFy);
  setVal("reportsMonthFilter", currentMonth);
}

// ----------------- TAB NAVIGATION -----------------
function switchTab(tabId) {
  document.querySelectorAll(".tab-view").forEach(el => el.classList.add("hidden"));
  const target = document.getElementById(`tab-${tabId}`);
  if (target) target.classList.remove("hidden");

  document.querySelectorAll(".nav-btn").forEach(btn => {
    btn.className = "nav-btn w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all text-slate-400 hover:text-white hover:bg-slate-800/60";
  });

  const activeBtn = document.getElementById(`nav-${tabId}`);
  if (activeBtn) {
    activeBtn.className = "nav-btn w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all bg-sky-600/20 text-sky-400 border border-sky-500/30";
  }

  const titles = {
    "dashboard": "GST Overview & Input Tax Credit (ITC) Dashboard",
    "sales": "Sales Invoices (Outward Supplies)",
    "purchases": "Purchase Bills & ITC Upload Hub",
    "itc-ledger": "GST Credit (ITC) & Tax Set-off Ledger",
    "parties": "Customers & Vendors Directory",
    "inventory": "Products & Services (HSN Master)",
    "reports": "GSTR-1 & GSTR-3B Tax Filing Reports",
    "settings": "Company Profile & GST Configuration"
  };
  document.getElementById("topHeaderTitle").innerText = titles[tabId] || "GST Management";

  if (tabId === "dashboard") loadDashboardData();
  if (tabId === "sales") loadSalesInvoices();
  if (tabId === "purchases") loadPurchaseBills();
  if (tabId === "itc-ledger") loadDashboardData();
  if (tabId === "parties") loadParties();
  if (tabId === "inventory") loadItems();
  if (tabId === "reports") onReportsPeriodChange();
  if (tabId === "settings") loadCompanySettings();

  lucide.createIcons();
}

// ----------------- STATE CODES & INITIAL LOOKUPS -----------------
async function loadStateCodes() {
  try {
    const res = await fetch("/api/state-codes");
    const data = await res.json();
    stateCodes = data.states || [];

    const dropdownIds = ["invPartyState", "cfgState", "partyStateInput"];
    dropdownIds.forEach(id => {
      const select = document.getElementById(id);
      if (!select) return;
      select.innerHTML = "";
      stateCodes.forEach(s => {
        const opt = document.createElement("option");
        opt.value = `${s.code} - ${s.name}`;
        opt.text = `${s.code} - ${s.name}`;
        select.appendChild(opt);
      });
    });
  } catch (err) {
    console.error("Failed to load state codes", err);
  }
}

function getStateCodeFromGstin(gstin) {
  if (gstin && gstin.trim().length >= 2) {
    return gstin.trim().substring(0, 2);
  }
  return "";
}

// ----------------- DASHBOARD & METRICS -----------------
async function loadDashboardData(targetFy, targetMonth) {
  try {
    const fy = targetFy !== undefined ? targetFy : (document.getElementById("dashFyFilter")?.value || "2025-26");
    const month = targetMonth !== undefined ? targetMonth : (document.getElementById("dashMonthFilter")?.value || "06");

    let url = "/api/dashboard";
    const params = [];
    if (fy && fy !== "ALL") params.push(`fy=${encodeURIComponent(fy)}`);
    if (month && month !== "ALL") params.push(`month=${encodeURIComponent(month)}`);
    if (params.length > 0) {
      url += `?${params.join("&")}`;
    }

    const res = await fetch(url);
    const data = await res.json();

    companyProfile = data.company || {};
    const metrics = data.metrics || {};
    const tax = data.tax_summary || {};
    const outputTax = tax.output_tax || {};
    const itc = tax.input_tax_credit || {};
    const net = tax.net_payable || {};
    const closing = tax.closing_credit_balance || {};
    const activePeriod = data.active_period || {};

    if (document.getElementById("sidebarCompanyName")) {
      document.getElementById("sidebarCompanyName").innerText = companyProfile.name || "My Business";
    }
    if (document.getElementById("sidebarGstin")) {
      document.getElementById("sidebarGstin").innerText = companyProfile.gstin || "Unregistered";
    }

    if (document.getElementById("dashActivePeriodText")) {
      document.getElementById("dashActivePeriodText").innerText = activePeriod.label || `FY ${fy} • ${getMonthName(month)}`;
    }

    // Top Metric Cards
    document.getElementById("cardOutputTax").innerText = `₹ ${(outputTax.total || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    document.getElementById("cardSalesCount").innerText = `${metrics.total_sales_count || 0} Invoices`;

    document.getElementById("cardInputTax").innerText = `₹ ${(itc.total || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    document.getElementById("cardPurchaseCount").innerText = `${metrics.total_purchase_count || 0} Bills`;

    const netPayableVal = net.total || 0;
    const closingCreditVal = closing.total || 0;

    if (netPayableVal > 0) {
      document.getElementById("cardNetLabel").innerText = "Monthly Net GST Payable";
      document.getElementById("cardNetPayable").innerText = `₹ ${netPayableVal.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      document.getElementById("cardNetPayable").className = "text-2xl font-extrabold text-rose-600 mt-3";
      document.getElementById("cardNetSubtext").innerText = "Liability to Pay in Cash (PMT-06)";
      document.getElementById("cardNetSubtext").className = "text-rose-600 font-semibold";
      document.getElementById("cardNetBar").className = "absolute bottom-0 left-0 right-0 h-1 bg-rose-500";
    } else {
      document.getElementById("cardNetLabel").innerText = "Monthly ITC Carry Forward";
      document.getElementById("cardNetPayable").innerText = `₹ ${closingCreditVal.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      document.getElementById("cardNetPayable").className = "text-2xl font-extrabold text-emerald-600 mt-3";
      document.getElementById("cardNetSubtext").innerText = "Surplus Input Credit Balance";
      document.getElementById("cardNetSubtext").className = "text-emerald-600 font-semibold";
      document.getElementById("cardNetBar").className = "absolute bottom-0 left-0 right-0 h-1 bg-emerald-500";
    }

    document.getElementById("cardTotalSales").innerText = `₹ ${(metrics.total_sales_value || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    document.getElementById("cardReceivables").innerText = `₹ ${(metrics.receivables || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})} Due`;

    // CA Tax Computation & Offset Statement Box
    if (document.getElementById("caB2bSales")) {
      document.getElementById("caB2bSales").innerText = `₹ ${(metrics.total_b2b_sales || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    }
    if (document.getElementById("caB2cSales")) {
      document.getElementById("caB2cSales").innerText = `₹ ${(metrics.total_b2c_sales || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    }
    if (document.getElementById("caOutputGst")) {
      document.getElementById("caOutputGst").innerText = `₹ ${(outputTax.total || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    }
    if (document.getElementById("caTaxablePurchases")) {
      document.getElementById("caTaxablePurchases").innerText = `₹ ${(metrics.total_taxable_purchase || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    }
    if (document.getElementById("caEligibleItc")) {
      document.getElementById("caEligibleItc").innerText = `₹ ${(itc.total || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    }
    if (document.getElementById("caBlockedItc")) {
      document.getElementById("caBlockedItc").innerText = `₹ ${(itc.blocked_itc || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    }
    if (document.getElementById("caSumOutput")) {
      document.getElementById("caSumOutput").innerText = `₹ ${(outputTax.total || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    }
    if (document.getElementById("caSumItc")) {
      document.getElementById("caSumItc").innerText = `(-) ₹ ${(itc.total || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    }
    if (document.getElementById("caNetCashLabel") && document.getElementById("caNetCashVal")) {
      if (netPayableVal > 0) {
        document.getElementById("caNetCashLabel").innerText = "Net Tax To Pay (Cash):";
        document.getElementById("caNetCashLabel").className = "text-amber-300 font-bold";
        document.getElementById("caNetCashVal").innerText = `₹ ${netPayableVal.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
        document.getElementById("caNetCashVal").className = "text-amber-300 text-sm font-extrabold";
      } else {
        document.getElementById("caNetCashLabel").innerText = "Net Credit C/F:";
        document.getElementById("caNetCashLabel").className = "text-emerald-400 font-bold";
        document.getElementById("caNetCashVal").innerText = `₹ ${closingCreditVal.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
        document.getElementById("caNetCashVal").className = "text-emerald-400 text-sm font-extrabold";
      }
    }

    // Dashboard Quick Export Links for selected period
    const quickQuery = `?fy=${encodeURIComponent(fy)}&month=${encodeURIComponent(month)}`;
    if (document.getElementById("btnDashQuickGstr1")) {
      document.getElementById("btnDashQuickGstr1").href = `/api/reports/gstr1/excel${quickQuery}`;
    }
    if (document.getElementById("btnDashQuickGstr3b")) {
      document.getElementById("btnDashQuickGstr3b").href = `/api/reports/gstr3b/excel${quickQuery}`;
    }
    if (document.getElementById("btnDashQuickSales")) {
      document.getElementById("btnDashQuickSales").href = `/api/reports/sales/excel${quickQuery}`;
    }
    if (document.getElementById("btnDashQuickPurchases")) {
      document.getElementById("btnDashQuickPurchases").href = `/api/reports/purchases/excel${quickQuery}`;
    }

    // Live ITC Pool (CGST, SGST, IGST)
    document.getElementById("poolCgstOutput").innerText = `₹ ${(outputTax.cgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    document.getElementById("poolCgstInput").innerText = `₹ ${(itc.cgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    document.getElementById("poolCgstNet").innerText = `₹ ${(net.cgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;

    document.getElementById("poolSgstOutput").innerText = `₹ ${(outputTax.sgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    document.getElementById("poolSgstInput").innerText = `₹ ${(itc.sgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    document.getElementById("poolSgstNet").innerText = `₹ ${(net.sgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;

    document.getElementById("poolIgstOutput").innerText = `₹ ${(outputTax.igst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    document.getElementById("poolIgstInput").innerText = `₹ ${(itc.igst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    document.getElementById("poolIgstNet").innerText = `₹ ${(net.igst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;

    // GST Credit Ledger tab sync
    if (document.getElementById("ledgerOutwardTotal")) {
      document.getElementById("ledgerOutwardTotal").innerText = `₹ ${(outputTax.total || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      document.getElementById("ledgerOutwardCgst").innerText = `₹ ${(outputTax.cgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      document.getElementById("ledgerOutwardSgst").innerText = `₹ ${(outputTax.sgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      document.getElementById("ledgerOutwardIgst").innerText = `₹ ${(outputTax.igst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;

      document.getElementById("ledgerItcTotal").innerText = `₹ ${(itc.total || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      document.getElementById("ledgerItcCgst").innerText = `₹ ${(itc.cgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      document.getElementById("ledgerItcSgst").innerText = `₹ ${(itc.sgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      document.getElementById("ledgerItcIgst").innerText = `₹ ${(itc.igst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;

      document.getElementById("ledgerBlockedItc").innerText = `₹ ${(itc.blocked_itc || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;

      document.getElementById("ledgerNetPayableTotal").innerText = `₹ ${(net.total || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      document.getElementById("ledgerNetCgst").innerText = `₹ ${(net.cgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      document.getElementById("ledgerNetSgst").innerText = `₹ ${(net.sgst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      document.getElementById("ledgerNetIgst").innerText = `₹ ${(net.igst || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    }

    renderRecentActivity(data.recent_activity || []);
    lucide.createIcons();
  } catch (err) {
    console.error("Error loading dashboard data", err);
  }
}

function onDashboardPeriodChange() {
  const fy = document.getElementById("dashFyFilter") ? document.getElementById("dashFyFilter").value : "2025-26";
  const month = document.getElementById("dashMonthFilter") ? document.getElementById("dashMonthFilter").value : "06";
  loadDashboardData(fy, month);
}

function onDashboardPrevMonth() {
  const fyMonths = ["04", "05", "06", "07", "08", "09", "10", "11", "12", "01", "02", "03"];
  const select = document.getElementById("dashMonthFilter");
  if (!select) return;
  const curr = select.value;
  let idx = fyMonths.indexOf(curr);
  if (idx === -1) {
    select.value = "04";
  } else {
    idx = (idx - 1 + fyMonths.length) % fyMonths.length;
    select.value = fyMonths[idx];
  }
  onDashboardPeriodChange();
}

function onDashboardNextMonth() {
  const fyMonths = ["04", "05", "06", "07", "08", "09", "10", "11", "12", "01", "02", "03"];
  const select = document.getElementById("dashMonthFilter");
  if (!select) return;
  const curr = select.value;
  let idx = fyMonths.indexOf(curr);
  if (idx === -1) {
    select.value = "04";
  } else {
    idx = (idx + 1) % fyMonths.length;
    select.value = fyMonths[idx];
  }
  onDashboardPeriodChange();
}

function downloadCaMonthlyZip() {
  const fy = document.getElementById("dashFyFilter")?.value || "2025-26";
  const month = document.getElementById("dashMonthFilter")?.value || "06";
  window.location.href = `/api/reports/ca-package/zip?fy=${encodeURIComponent(fy)}&month=${encodeURIComponent(month)}`;
}

function downloadCaMasterExcel() {
  const fy = document.getElementById("dashFyFilter")?.value || "2025-26";
  const month = document.getElementById("dashMonthFilter")?.value || "06";
  window.location.href = `/api/reports/ca-master/excel?fy=${encodeURIComponent(fy)}&month=${encodeURIComponent(month)}`;
}

function renderRecentActivity(list) {
  const tbody = document.getElementById("recentActivityTbody");
  if (!tbody) return;
  tbody.innerHTML = "";

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" class="text-center py-6 text-slate-400">No recent transactions recorded</td></tr>`;
    return;
  }

  list.forEach(item => {
    const isSale = item.type === "SALE";
    const typeBadge = isSale 
      ? `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-700">Sale</span>`
      : `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-700">Purchase</span>`;

    const statusBadge = item.status === "PAID"
      ? `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">Paid</span>`
      : item.status === "PARTIAL"
      ? `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700">Partial</span>`
      : `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700">Unpaid</span>`;

    const tr = document.createElement("tr");
    tr.className = "hover:bg-slate-50 transition";
    tr.innerHTML = `
      <td class="py-3 px-4">${typeBadge}</td>
      <td class="py-3 px-4 font-bold text-slate-800">${item.number}</td>
      <td class="py-3 px-4 text-slate-700">${item.party}</td>
      <td class="py-3 px-4 text-slate-500">${item.date}</td>
      <td class="py-3 px-4 text-right font-medium text-slate-600">₹ ${item.tax.toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
      <td class="py-3 px-4 text-right font-bold text-slate-900">₹ ${item.amount.toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
      <td class="py-3 px-4 text-center">${statusBadge}</td>
      <td class="py-3 px-4 text-center text-slate-500 text-[11px]">${item.tag}</td>
    `;
    tbody.appendChild(tr);
  });
}

// ----------------- FINANCIAL YEAR & PERIOD UTILITIES -----------------
function getFinancialYear(dateStr) {
  if (!dateStr || !dateStr.includes("-")) return "";
  const parts = dateStr.split("-");
  const y = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10);
  if (isNaN(y) || isNaN(m)) return "";
  if (m >= 4) {
    return `${y}-${String(y + 1).slice(2)}`;
  } else {
    return `${y - 1}-${String(y).slice(2)}`;
  }
}

function getQuarter(dateStr) {
  if (!dateStr || !dateStr.includes("-")) return "";
  const m = parseInt(dateStr.split("-")[1], 10);
  if (isNaN(m)) return "";
  if (m >= 4 && m <= 6) return "Q1";
  if (m >= 7 && m <= 9) return "Q2";
  if (m >= 10 && m <= 12) return "Q3";
  return "Q4";
}

function getMonthCode(dateStr) {
  if (!dateStr || !dateStr.includes("-")) return "";
  return dateStr.split("-")[1];
}

function getQuarterLabel(q) {
  const map = {
    "Q1": "Q1 (Apr - Jun)",
    "Q2": "Q2 (Jul - Sep)",
    "Q3": "Q3 (Oct - Dec)",
    "Q4": "Q4 (Jan - Mar)"
  };
  return map[q] || q;
}

function getMonthName(mCode) {
  const map = {
    "01": "January", "02": "February", "03": "March", "04": "April",
    "05": "May", "06": "June", "07": "July", "08": "August",
    "09": "September", "10": "October", "11": "November", "12": "December"
  };
  return map[mCode] || mCode;
}

// ----------------- SALES INVOICES -----------------
async function loadSalesInvoices() {
  try {
    const res = await fetch("/api/invoices");
    const data = await res.json();
    allInvoices = data.invoices || [];
    filterSales();
  } catch (err) {
    console.error("Error loading sales invoices", err);
  }
}

function onSalesPeriodModeChange() {
  const mode = document.getElementById("salesPeriodMode") ? document.getElementById("salesPeriodMode").value : "ALL";
  if (document.getElementById("salesQuarterWrapper")) document.getElementById("salesQuarterWrapper").classList.toggle("hidden", mode !== "QUARTER");
  if (document.getElementById("salesMonthWrapper")) document.getElementById("salesMonthWrapper").classList.toggle("hidden", mode !== "MONTH");
  if (document.getElementById("salesCustomFromWrapper")) document.getElementById("salesCustomFromWrapper").classList.toggle("hidden", mode !== "CUSTOM");
  if (document.getElementById("salesCustomToWrapper")) document.getElementById("salesCustomToWrapper").classList.toggle("hidden", mode !== "CUSTOM");
  filterSales();
}

function resetSalesFilters() {
  if (document.getElementById("salesFyFilter")) document.getElementById("salesFyFilter").value = "2025-26";
  if (document.getElementById("salesPeriodMode")) document.getElementById("salesPeriodMode").value = "ALL";
  if (document.getElementById("salesQuarterFilter")) document.getElementById("salesQuarterFilter").value = "ALL";
  if (document.getElementById("salesMonthFilter")) document.getElementById("salesMonthFilter").value = "ALL";
  if (document.getElementById("salesDateFrom")) document.getElementById("salesDateFrom").value = "";
  if (document.getElementById("salesDateTo")) document.getElementById("salesDateTo").value = "";
  if (document.getElementById("salesTypeFilter")) document.getElementById("salesTypeFilter").value = "ALL";
  if (document.getElementById("salesStatusFilter")) document.getElementById("salesStatusFilter").value = "ALL";
  if (document.getElementById("salesSearchInput")) document.getElementById("salesSearchInput").value = "";
  onSalesPeriodModeChange();
}

function exportFilteredSalesExcel() {
  const fy = document.getElementById("salesFyFilter")?.value || "ALL";
  const mode = document.getElementById("salesPeriodMode")?.value || "ALL";
  const quarter = document.getElementById("salesQuarterFilter")?.value || "ALL";
  const month = document.getElementById("salesMonthFilter")?.value || "ALL";
  const fromDate = document.getElementById("salesDateFrom")?.value || "";
  const toDate = document.getElementById("salesDateTo")?.value || "";

  let url = `/api/reports/sales/excel?fy=${encodeURIComponent(fy)}`;
  if (mode === "QUARTER" && quarter !== "ALL") url += `&quarter=${encodeURIComponent(quarter)}`;
  if (mode === "MONTH" && month !== "ALL") url += `&month=${encodeURIComponent(month)}`;
  if (mode === "CUSTOM") {
    if (fromDate) url += `&start_date=${encodeURIComponent(fromDate)}`;
    if (toDate) url += `&end_date=${encodeURIComponent(toDate)}`;
  }
  window.location.href = url;
}

function filterSales() {
  const fyFilter = document.getElementById("salesFyFilter") ? document.getElementById("salesFyFilter").value : "ALL";
  const mode = document.getElementById("salesPeriodMode") ? document.getElementById("salesPeriodMode").value : "ALL";
  const quarterFilter = document.getElementById("salesQuarterFilter") ? document.getElementById("salesQuarterFilter").value : "ALL";
  const monthFilter = document.getElementById("salesMonthFilter") ? document.getElementById("salesMonthFilter").value : "ALL";
  const fromDate = document.getElementById("salesDateFrom") ? document.getElementById("salesDateFrom").value : "";
  const toDate = document.getElementById("salesDateTo") ? document.getElementById("salesDateTo").value : "";
  const search = document.getElementById("salesSearchInput") ? document.getElementById("salesSearchInput").value.toLowerCase().trim() : "";
  const typeF = document.getElementById("salesTypeFilter") ? document.getElementById("salesTypeFilter").value : "ALL";
  const statusF = document.getElementById("salesStatusFilter") ? document.getElementById("salesStatusFilter").value : "ALL";

  let periodDescription = fyFilter === "ALL" ? "All Financial Years" : `FY ${fyFilter}`;
  if (mode === "QUARTER" && quarterFilter !== "ALL") {
    periodDescription += ` • ${getQuarterLabel(quarterFilter)}`;
  } else if (mode === "MONTH" && monthFilter !== "ALL") {
    periodDescription += ` • ${getMonthName(monthFilter)}`;
  } else if (mode === "CUSTOM" && (fromDate || toDate)) {
    periodDescription += ` • (${fromDate || 'Start'} to ${toDate || 'End'})`;
  }

  const filtered = allInvoices.filter(inv => {
    const invDate = inv.invoice_date || "";
    const invFy = getFinancialYear(invDate);
    const invQ = getQuarter(invDate);
    const invMonth = getMonthCode(invDate);

    // FY Filter
    if (fyFilter !== "ALL" && invFy !== fyFilter) return false;

    // Period Mode Filter
    if (mode === "QUARTER" && quarterFilter !== "ALL") {
      if (invQ !== quarterFilter) return false;
    } else if (mode === "MONTH" && monthFilter !== "ALL") {
      if (invMonth !== monthFilter) return false;
    } else if (mode === "CUSTOM") {
      if (fromDate && invDate < fromDate) return false;
      if (toDate && invDate > toDate) return false;
    }

    // Type Filter
    if (typeF !== "ALL" && inv.invoice_type !== typeF) return false;

    // Status Filter
    if (statusF !== "ALL" && inv.payment_status !== statusF) return false;

    // Search Filter
    if (search) {
      const match = (inv.invoice_number || "").toLowerCase().includes(search) ||
                    (inv.party_name || "").toLowerCase().includes(search) ||
                    (inv.party_gstin || "").toLowerCase().includes(search);
      if (!match) return false;
    }

    return true;
  });

  // Calculate CA Summary metrics for the filtered period
  let totalTaxable = 0;
  let totalCgst = 0;
  let totalSgst = 0;
  let totalIgst = 0;
  let totalGross = 0;

  filtered.forEach(inv => {
    totalTaxable += Number(inv.taxable_amount || 0);
    totalCgst += Number(inv.cgst_amount || 0);
    totalSgst += Number(inv.sgst_amount || 0);
    totalIgst += Number(inv.igst_amount || 0);
    totalGross += Number(inv.total_amount || 0);
  });

  const totalCgstSgst = totalCgst + totalSgst;

  if (document.getElementById("salesSummaryPeriodBadge")) {
    document.getElementById("salesSummaryPeriodBadge").innerText = periodDescription;
  }
  if (document.getElementById("salesSummaryCount")) {
    document.getElementById("salesSummaryCount").innerText = `${filtered.length} Invoices`;
  }
  if (document.getElementById("salesSummaryTaxable")) {
    document.getElementById("salesSummaryTaxable").innerText = `₹ ${totalTaxable.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }
  if (document.getElementById("salesSummaryCgstSgst")) {
    document.getElementById("salesSummaryCgstSgst").innerText = `₹ ${totalCgstSgst.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }
  if (document.getElementById("salesSummaryIgst")) {
    document.getElementById("salesSummaryIgst").innerText = `₹ ${totalIgst.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }
  if (document.getElementById("salesSummaryGrandTotal")) {
    document.getElementById("salesSummaryGrandTotal").innerText = `₹ ${totalGross.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }

  renderSalesTable(filtered);
}

function renderSalesTable(list) {
  const tbody = document.getElementById("salesInvoicesTbody");
  if (!tbody) return;
  tbody.innerHTML = "";

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="11" class="text-center py-8 text-slate-400">No invoices match your selected period or filters</td></tr>`;
    return;
  }

  list.forEach(inv => {
    const statusBadge = inv.payment_status === "PAID"
      ? `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">Paid</span>`
      : inv.payment_status === "PARTIAL"
      ? `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700">Partial</span>`
      : `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700">Unpaid</span>`;

    const totalGst = (inv.cgst_amount || 0) + (inv.sgst_amount || 0) + (inv.igst_amount || 0);
    const invFy = getFinancialYear(inv.invoice_date);
    const invQ = getQuarter(inv.invoice_date);

    const tr = document.createElement("tr");
    tr.className = "hover:bg-slate-50/80 transition";
    tr.innerHTML = `
      <td class="py-3 px-4 font-bold text-sky-700 font-mono">${inv.invoice_number}</td>
      <td class="py-3 px-4"><span class="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">${inv.invoice_type}</span></td>
      <td class="py-3 px-4 font-medium text-slate-800">${inv.party_name}</td>
      <td class="py-3 px-4 font-mono text-[11px] text-slate-500">${inv.party_gstin || 'Unregistered'}</td>
      <td class="py-3 px-4 text-slate-600">${inv.invoice_date}</td>
      <td class="py-3 px-4 text-slate-500 font-mono text-[11px]"><span class="font-bold text-slate-700">FY ${invFy}</span> <span class="text-[10px] bg-slate-100 px-1 py-0.5 rounded font-semibold text-slate-600">${invQ}</span></td>
      <td class="py-3 px-4 text-right text-slate-600">₹ ${(inv.taxable_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
      <td class="py-3 px-4 text-right font-medium text-indigo-600">₹ ${totalGst.toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
      <td class="py-3 px-4 text-right font-bold text-slate-900">₹ ${(inv.total_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
      <td class="py-3 px-4 text-center">${statusBadge}</td>
      <td class="py-3 px-4 text-center">
        <div class="flex items-center justify-center gap-1.5">
          <button onclick="viewInvoiceDetail(${inv.id})" title="View / Print Tax Invoice" class="p-1.5 text-slate-600 hover:text-sky-600 hover:bg-sky-50 rounded-lg transition">
            <i data-lucide="eye" class="w-4 h-4"></i>
          </button>
          <a href="/api/invoices/${inv.id}/pdf" target="_blank" title="Download PDF" class="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition">
            <i data-lucide="download" class="w-4 h-4"></i>
          </a>
          <button onclick="deleteInvoice(${inv.id})" title="Delete Invoice" class="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition">
            <i data-lucide="trash-2" class="w-4 h-4"></i>
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });

  lucide.createIcons();
}

async function viewInvoiceDetail(invId) {
  try {
    const res = await fetch(`/api/invoices/${invId}`);
    const data = await res.json();
    currentInvoiceData = data;

    const inv = data.invoice;
    const items = data.items || [];
    const comp = data.company || {};

    document.getElementById("viewInvNumberTitle").innerText = inv.invoice_number;
    document.getElementById("viewInvTypeTag").innerText = inv.invoice_type === "B2B" ? "TAX INVOICE" : "RETAIL INVOICE";
    document.getElementById("viewInvPdfDownloadBtn").href = `/api/invoices/${inv.id}/pdf`;

    const isInterstate = Boolean(inv.is_interstate);

    let formattedDate = inv.invoice_date || '';
    if (formattedDate.includes('-')) {
      const p = formattedDate.split('-');
      if (p.length === 3 && p[0].length === 4) {
        formattedDate = `${p[2]}/${p[1]}/${p[0]}`;
      }
    }

    let itemsHtml = "";
    items.forEach((it) => {
      const qtyFormatted = Number(it.quantity).toFixed(3) + (it.uom ? ' ' + it.uom : ' Units');
      const rateFormatted = Number(it.rate).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2});
      const taxableFormatted = Number(it.taxable_value).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2});
      const hsnText = it.hsn_code ? `<div class="text-[10px] text-slate-600 mt-0.5">HSN/SAC Code:${it.hsn_code}</div>` : '';

      itemsHtml += `
        <tr class="align-top border-b border-black">
          <td class="border border-black p-2.5 text-left">
            <div class="font-bold text-slate-900">${it.item_name}</div>
            ${hsnText}
          </td>
          <td class="border border-black p-2.5 text-center">${qtyFormatted}</td>
          <td class="border border-black p-2.5 text-right">${rateFormatted}</td>
          <td class="border border-black p-2.5 text-center font-medium">GST${Number(it.gst_rate)}%</td>
          <td class="border border-black p-2.5 text-right font-medium">₹ ${taxableFormatted}</td>
        </tr>
      `;
    });

    const userNotesHtml = inv.notes && inv.notes.trim() ? `
      <div class="mt-2 p-2.5 rounded-lg border border-[#002B66]/60 bg-sky-50 text-slate-900">
        <div class="font-bold text-[11px] text-[#002B66] mb-0.5">Notes / Remarks:</div>
        <div class="text-[11px] text-slate-800 leading-snug whitespace-pre-line">${inv.notes}</div>
      </div>
    ` : '';

    const termsHtml = (comp.invoice_terms && comp.invoice_terms.trim()) ? comp.invoice_terms.replace(/\n/g, '<br/>') : `1. Goods once sold will not be taken back.<br/>2. Warranty as per manufacturer terms.<br/>3. Subject to ${comp.city || 'Ahmedabad'} Jurisdiction.`;

    const printableHtml = `
      <div class="bg-white p-6 max-w-3xl mx-auto text-slate-900 text-xs font-sans">
        <!-- Top Section: Logo (Left) and Company + Customer Details (Right) -->
        <div class="flex justify-between items-start gap-6 pb-3">
          <div class="w-1/2 flex items-start">
            <img src="/static/sunpulse_logo.jpg" alt="SunPulse Energy Solutions" class="max-h-20 max-w-[240px] object-contain" onerror="this.outerHTML='<div class=\\'text-xl font-extrabold text-[#002B66]\\'>${comp.name || 'SUNPULSE ENERGY SOLUTIONS'}</div>'" />
          </div>
          <div class="w-1/2 text-right text-[11px] leading-tight text-slate-800">
            <div class="font-bold text-xs text-[#002B66]">${comp.name || 'SUNPULSE ENERGY SOLUTIONS'}</div>
            <div>${(comp.address || 'GF 56/4, CHHIPA NI CHALI/JUNI CHALI\nRAKHIYAL, Ahmedabad').replace(/\n/g, '<br/>')}</div>
            <div>${comp.city || 'AHMEDABAD'} ${comp.pincode || '380023'}</div>
            <div>${comp.state || 'Gujarat'} GJ</div>
            <div>${comp.country || 'India'}</div>
            <div class="font-bold">GSTIN: ${comp.gstin || '24MVMPS3622M1ZT'}</div>

            <div class="mt-3">
              <div class="font-bold">To,</div>
              <div class="font-bold text-slate-900">${inv.party_name || 'Customer'}</div>
              <div>${(inv.party_address || '').replace(/\n/g, '<br/>')}</div>
              <div class="font-bold">GSTNO:${inv.party_gstin || 'N/A'}</div>
              ${inv.party_email ? `<div>${inv.party_email}</div>` : ''}
            </div>
          </div>
        </div>

        <!-- Invoice Title, Date & Sales Person -->
        <div class="mt-3 mb-3">
          <h2 class="text-xl font-black text-[#002B66] tracking-tight mb-1.5">${inv.invoice_number || 'INVOICE/01'}</h2>
          <div class="grid grid-cols-2 gap-4 text-xs">
            <div>
              <div class="font-bold text-[#002B66]">Invoice Date:</div>
              <div class="text-slate-800 font-medium">${formattedDate}</div>
            </div>
            <div>
              <div class="font-bold text-[#002B66]">Sales person:</div>
              <div class="text-slate-800 font-medium uppercase">${inv.sales_person || 'SUFIYAN SHAIKH'}</div>
            </div>
          </div>
        </div>

        <!-- Items Table -->
        <table class="w-full text-xs border border-black border-collapse mt-2">
          <thead class="border-b border-black">
            <tr class="font-bold text-black text-center bg-slate-50">
              <th class="border border-black p-1.5 text-left">DESCRIPTION</th>
              <th class="border border-black p-1.5 w-24">QUANTITY</th>
              <th class="border border-black p-1.5 w-24">UNIT PRICE</th>
              <th class="border border-black p-1.5 w-20">TAXES</th>
              <th class="border border-black p-1.5 w-28">AMOUNT</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHtml}
          </tbody>
        </table>

        <!-- Bottom Section: Left (Words, Bank, Notes, Terms) & Right (Totals Summary, Signatory) -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
          <!-- Left Column -->
          <div class="space-y-2 text-[11px]">
            <div>
              <div class="font-bold text-[#002B66]">Amount Chargeable (in words):</div>
              <div class="text-slate-800 italic font-medium">${inv.amount_in_words || 'Zero Rupees Only'}</div>
            </div>

            <div class="p-2 rounded border border-slate-300 bg-slate-50 text-[10.5px] leading-snug">
              <div class="font-bold text-[#002B66]">Company Bank Details:</div>
              <div>Bank: <b>${comp.bank_name || 'HDFC Bank Ltd'}</b> | A/C No: <b>${comp.bank_acc || '50200084729101'}</b></div>
              <div>IFSC: <b>${comp.bank_ifsc || 'HDFC0001024'}</b> | Branch: <b>${comp.bank_branch || 'Ahmedabad Branch'}</b> | UPI: <b>${comp.upi_id || 'sunpulse@hdfcbank'}</b></div>
            </div>

            ${userNotesHtml}

            <div class="text-[10px] text-slate-600 leading-tight">
              <div class="font-bold text-slate-700">Terms & Conditions:</div>
              <div>${termsHtml}</div>
            </div>
          </div>

          <!-- Right Column -->
          <div class="flex flex-col items-end justify-between">
            <div class="w-full max-w-[280px] border border-black border-collapse text-xs">
              <div class="flex justify-between p-1.5 px-2.5 border-b border-black">
                <span>Untaxed Amount</span>
                <span class="font-medium">₹ ${Number(inv.taxable_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
              </div>
              ${isInterstate ? `
                <div class="flex justify-between p-1.5 px-2.5 border-b border-black">
                  <span>IGST</span>
                  <span class="font-medium">₹ ${Number(inv.igst_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
              ` : `
                <div class="flex justify-between p-1.5 px-2.5 border-b border-black">
                  <span>SGST</span>
                  <span class="font-medium">₹ ${Number(inv.sgst_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
                <div class="flex justify-between p-1.5 px-2.5 border-b border-black">
                  <span>CGST</span>
                  <span class="font-medium">₹ ${Number(inv.cgst_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
              `}
              <div class="flex justify-between p-1.5 px-2.5 bg-[#002B66] text-white font-bold text-xs">
                <span>Total</span>
                <span>₹ ${Number(inv.total_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
              </div>
            </div>

            <div class="text-right text-[11px] font-bold text-slate-900 mt-6">
              <div>For ${comp.name || 'SUNPULSE ENERGY SOLUTIONS'}</div>
              <div class="h-10"></div>
              <div>Authorized Signatory</div>
            </div>
          </div>
        </div>

        <!-- Footer Page Indicator & Line -->
        <div class="mt-4 text-center text-[10px] text-slate-500">
          <div>Page:1/1</div>
          <hr class="border-t border-black mt-1" />
        </div>
      </div>
    `;

    document.getElementById("printableInvoice").innerHTML = printableHtml;
    document.getElementById("viewInvoiceModal").classList.remove("hidden");
    lucide.createIcons();
  } catch (err) {
    console.error("Error viewing invoice", err);
  }
}

function closeViewInvoiceModal() {
  document.getElementById("viewInvoiceModal").classList.add("hidden");
}

function printCurrentInvoice() {
  window.print();
}

async function deleteInvoice(invId) {
  if (!confirm("Are you sure you want to delete this invoice?")) return;
  try {
    await fetch(`/api/invoices/${invId}`, { method: "DELETE" });
    await loadSalesInvoices();
    await loadDashboardData();
  } catch (err) {
    console.error("Error deleting invoice", err);
  }
}

// ----------------- CREATE INVOICE -----------------
function openNewInvoiceModal() {
  document.getElementById("newInvoiceForm").reset();
  const today = new Date().toISOString().split("T")[0];
  document.getElementById("invDate").value = today;

  const tbody = document.getElementById("invoiceItemsTbody");
  tbody.innerHTML = "";
  addInvoiceLineRow();

  const custSelect = document.getElementById("invCustomerSelect");
  custSelect.innerHTML = `<option value="">-- Choose Existing Customer --</option>`;
  allParties.filter(p => p.type === "CUSTOMER" || p.type === "BOTH").forEach(p => {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.text = `${p.name} (${p.gstin || 'B2C'})`;
    custSelect.appendChild(opt);
  });

  recalculateInvoiceLineItems();
  document.getElementById("newInvoiceModal").classList.remove("hidden");
  lucide.createIcons();
}

function closeNewInvoiceModal() {
  document.getElementById("newInvoiceModal").classList.add("hidden");
}

function handleCustomerSelect() {
  const custId = document.getElementById("invCustomerSelect").value;
  if (!custId) return;

  const party = allParties.find(p => p.id == custId);
  if (party) {
    document.getElementById("invPartyName").value = party.name;
    document.getElementById("invPartyGstin").value = party.gstin || "";
    document.getElementById("invPartyAddress").value = party.billing_address || "";
    
    if (party.state && party.state_code) {
      document.getElementById("invPartyState").value = `${party.state_code} - ${party.state}`;
    }
    recalculateInvoiceLineItems();
  }
}

function autoDetectBuyerStateFromGstin() {
  const gstin = document.getElementById("invPartyGstin").value;
  const code = getStateCodeFromGstin(gstin);
  if (code) {
    const found = stateCodes.find(s => s.code === code);
    if (found) {
      document.getElementById("invPartyState").value = `${found.code} - ${found.name}`;
      recalculateInvoiceLineItems();
    }
  }
}

function addInvoiceLineRow() {
  const tbody = document.getElementById("invoiceItemsTbody");
  const rowId = `item_row_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;

  const tr = document.createElement("tr");
  tr.id = rowId;
  tr.className = "hover:bg-slate-50/50";

  let itemOptions = `<option value="">-- Select product --</option>`;
  allItems.forEach(it => {
    itemOptions += `<option value="${it.id}" data-name="${it.name}" data-hsn="${it.hsn_code || ''}" data-uom="${it.uom}" data-price="${it.selling_price}" data-gst="${it.gst_rate}">${it.name} (₹${it.selling_price})</option>`;
  });

  tr.innerHTML = `
    <td class="py-2 px-3">
      <select onchange="onItemDropdownChange('${rowId}', this)" class="w-full text-xs p-1.5 rounded border border-slate-200 mb-1">
        ${itemOptions}
      </select>
      <input type="text" placeholder="Item Name" class="item-name w-full text-xs p-1.5 rounded border border-slate-200" required />
    </td>
    <td class="py-2 px-2">
      <input type="text" placeholder="HSN" class="item-hsn w-full text-xs p-1.5 rounded border border-slate-200 font-mono" />
    </td>
    <td class="py-2 px-2">
      <input type="number" step="any" value="1" min="0.001" oninput="onItemQtyChange('${rowId}')" class="item-qty w-full text-xs p-1.5 rounded border border-slate-200 text-center" required />
    </td>
    <td class="py-2 px-2">
      <input type="text" value="Pcs" class="item-uom w-full text-xs p-1.5 rounded border border-slate-200 text-center" />
    </td>
    <td class="py-2 px-2">
      <input type="number" step="any" value="0" min="0" oninput="onItemRateChange('${rowId}')" class="item-rate w-full text-xs p-1.5 rounded border border-slate-200 text-right font-semibold" required placeholder="0.00" title="Unit Price (Excl. GST)" />
    </td>
    <td class="py-2 px-2">
      <select onchange="onItemGstChange('${rowId}')" class="item-gst w-full text-xs p-1.5 rounded border border-slate-200 text-center font-medium">
        <option value="18" selected>18%</option>
        <option value="12">12%</option>
        <option value="8.9">8.9%</option>
        <option value="5">5%</option>
        <option value="28">28%</option>
        <option value="0">0%</option>
      </select>
    </td>
    <td class="py-2 px-3 text-right">
      <input type="number" step="any" value="0" min="0" oninput="onItemTotalChange('${rowId}')" class="item-total-input w-full text-xs p-1.5 rounded border border-sky-300 bg-sky-50/50 text-right font-bold text-sky-900 focus:bg-white focus:border-sky-500 transition" placeholder="0.00" title="Total (With GST). Type here to auto-calculate base Rate & GST!" />
    </td>
    <td class="py-2 px-2 text-center">
      <button type="button" onclick="removeInvoiceLineRow('${rowId}')" class="text-slate-400 hover:text-rose-600 p-1">
        <i data-lucide="trash" class="w-3.5 h-3.5"></i>
      </button>
    </td>
  `;

  tbody.appendChild(tr);
  lucide.createIcons();
  recalculateInvoiceLineItems();
}

// When user inputs Unit Rate (Excl. GST) -> Auto calculate Total
function onItemRateChange(rowId) {
  const row = document.getElementById(rowId);
  if (!row) return;
  const qty = parseFloat(row.querySelector(".item-qty")?.value) || 0;
  const rate = parseFloat(row.querySelector(".item-rate")?.value) || 0;
  const gst = parseFloat(row.querySelector(".item-gst")?.value) || 0;

  const taxable = qty * rate;
  const total = taxable * (1.0 + gst / 100.0);
  const totalInput = row.querySelector(".item-total-input");
  if (totalInput) {
    totalInput.value = total > 0 ? total.toFixed(2) : "";
  }
  recalculateInvoiceLineItems();
}

// When user inputs Total (Incl. GST) -> REVERSE AUTO CALCULATE Rate & GST!
function onItemTotalChange(rowId) {
  const row = document.getElementById(rowId);
  if (!row) return;
  const total = parseFloat(row.querySelector(".item-total-input")?.value) || 0;
  let qty = parseFloat(row.querySelector(".item-qty")?.value) || 0;
  if (qty <= 0) {
    qty = 1;
    row.querySelector(".item-qty").value = "1";
  }
  const gst = parseFloat(row.querySelector(".item-gst")?.value) || 0;

  const taxable = total / (1.0 + gst / 100.0);
  const rate = taxable / qty;

  const rateInput = row.querySelector(".item-rate");
  if (rateInput) {
    rateInput.value = rate > 0 ? (rate % 1 === 0 ? rate.toFixed(2) : rate.toFixed(4).replace(/0+$/, "").replace(/\.$/, "")) : "";
  }
  recalculateInvoiceLineItems();
}

// When user edits Quantity
function onItemQtyChange(rowId) {
  const row = document.getElementById(rowId);
  if (!row) return;
  const qty = parseFloat(row.querySelector(".item-qty")?.value) || 0;
  const rate = parseFloat(row.querySelector(".item-rate")?.value) || 0;
  const total = parseFloat(row.querySelector(".item-total-input")?.value) || 0;
  const gst = parseFloat(row.querySelector(".item-gst")?.value) || 0;

  if (rate > 0) {
    const taxable = qty * rate;
    const totalCalc = taxable * (1.0 + gst / 100.0);
    const totalInput = row.querySelector(".item-total-input");
    if (totalInput) totalInput.value = totalCalc > 0 ? totalCalc.toFixed(2) : "";
  } else if (total > 0) {
    onItemTotalChange(rowId);
  }
  recalculateInvoiceLineItems();
}

// When user changes GST Rate dropdown
function onItemGstChange(rowId) {
  const row = document.getElementById(rowId);
  if (!row) return;
  const rate = parseFloat(row.querySelector(".item-rate")?.value) || 0;
  const total = parseFloat(row.querySelector(".item-total-input")?.value) || 0;

  if (rate > 0) {
    onItemRateChange(rowId);
  } else if (total > 0) {
    onItemTotalChange(rowId);
  } else {
    recalculateInvoiceLineItems();
  }
}

function onItemDropdownChange(rowId, selectEl) {
  const row = document.getElementById(rowId);
  if (!row) return;

  const selectedOpt = selectEl.options[selectEl.selectedIndex];
  if (selectedOpt && selectedOpt.value) {
    row.querySelector(".item-name").value = selectedOpt.getAttribute("data-name") || "";
    row.querySelector(".item-hsn").value = selectedOpt.getAttribute("data-hsn") || "";
    row.querySelector(".item-uom").value = selectedOpt.getAttribute("data-uom") || "Pcs";
    row.querySelector(".item-rate").value = selectedOpt.getAttribute("data-price") || 0;
    
    const gstSelect = row.querySelector(".item-gst");
    const itemGst = selectedOpt.getAttribute("data-gst") || "18";
    const optionExists = Array.from(gstSelect.options).some(opt => parseFloat(opt.value) === parseFloat(itemGst));
    if (!optionExists) {
      const newOpt = document.createElement("option");
      newOpt.value = itemGst;
      newOpt.text = `${itemGst}%`;
      gstSelect.appendChild(newOpt);
    }
    gstSelect.value = itemGst;
    
    onItemRateChange(rowId);
  }
  recalculateInvoiceLineItems();
}

function removeInvoiceLineRow(rowId) {
  const tbody = document.getElementById("invoiceItemsTbody");
  if (tbody.children.length <= 1) {
    alert("At least one line item is required!");
    return;
  }
  const row = document.getElementById(rowId);
  if (row) row.remove();
  recalculateInvoiceLineItems();
}

function recalculateInvoiceLineItems() {
  const sellerStateCode = (companyProfile.state_code || "27").trim().padStart(2, "0");
  const buyerStateVal = document.getElementById("invPartyState")?.value || "";
  const buyerStateCode = buyerStateVal.split(" - ")[0].trim().padStart(2, "0");

  const isInterstate = (sellerStateCode !== buyerStateCode);

  const badge = document.getElementById("invTaxTypeBadge");
  const cgstRow = document.getElementById("invCgstRow");
  const sgstRow = document.getElementById("invSgstRow");
  const igstRow = document.getElementById("invIgstRow");

  if (isInterstate) {
    badge.innerText = `Inter-State Supply (IGST Applicable)`;
    badge.className = "text-xs font-bold text-purple-400";
    cgstRow.classList.add("hidden");
    sgstRow.classList.add("hidden");
    igstRow.classList.remove("hidden");
  } else {
    badge.innerText = `Intra-State Supply (CGST + SGST Applicable)`;
    badge.className = "text-xs font-bold text-sky-400";
    cgstRow.classList.remove("hidden");
    sgstRow.classList.remove("hidden");
    igstRow.classList.add("hidden");
  }

  let totalTaxable = 0;
  let totalCgst = 0;
  let totalSgst = 0;
  let totalIgst = 0;

  const rows = document.querySelectorAll("#invoiceItemsTbody tr");
  rows.forEach(row => {
    const qty = parseFloat(row.querySelector(".item-qty")?.value) || 0;
    const rate = parseFloat(row.querySelector(".item-rate")?.value) || 0;
    const gstRate = parseFloat(row.querySelector(".item-gst")?.value) || 0;

    const taxable = qty * rate;
    const taxAmt = (taxable * gstRate) / 100.0;
    const rowTotal = taxable + taxAmt;

    totalTaxable += taxable;

    if (isInterstate) {
      totalIgst += taxAmt;
    } else {
      totalCgst += taxAmt / 2.0;
      totalSgst += taxAmt / 2.0;
    }

    const totalInput = row.querySelector(".item-total-input");
    if (totalInput && document.activeElement !== totalInput && rowTotal > 0) {
      totalInput.value = rowTotal.toFixed(2);
    }
  });

  const grandTotal = Math.round(totalTaxable + totalCgst + totalSgst + totalIgst);

  document.getElementById("invTaxableSubtotal").innerText = `₹ ${totalTaxable.toFixed(2)}`;
  document.getElementById("invCgstTotal").innerText = `₹ ${totalCgst.toFixed(2)}`;
  document.getElementById("invSgstTotal").innerText = `₹ ${totalSgst.toFixed(2)}`;
  document.getElementById("invIgstTotal").innerText = `₹ ${totalIgst.toFixed(2)}`;
  document.getElementById("invGrandTotal").innerText = `₹ ${grandTotal.toFixed(2)}`;
  document.getElementById("invWordsPreview").innerText = `Grand Total: ₹ ${grandTotal.toLocaleString('en-IN')}`;
}

async function handleCreateInvoiceSubmit(e) {
  e.preventDefault();

  const buyerStateVal = document.getElementById("invPartyState").value;
  const buyerStateCode = buyerStateVal.split(" - ")[0].trim();
  const buyerStateName = buyerStateVal.split(" - ")[1]?.trim() || buyerStateVal;

  const items = [];
  document.querySelectorAll("#invoiceItemsTbody tr").forEach(row => {
    const name = row.querySelector(".item-name").value.trim();
    if (!name) return;
    items.push({
      item_name: name,
      hsn_code: row.querySelector(".item-hsn").value.trim(),
      quantity: parseFloat(row.querySelector(".item-qty").value) || 1,
      uom: row.querySelector(".item-uom").value.trim() || "Pcs",
      rate: parseFloat(row.querySelector(".item-rate").value) || 0,
      discount_percent: 0,
      gst_rate: parseFloat(row.querySelector(".item-gst").value) || 18
    });
  });

  if (items.length === 0) {
    alert("Please add at least one valid invoice item!");
    return;
  }

  const payload = {
    invoice_number: document.getElementById("invNumber").value.trim(),
    invoice_type: document.getElementById("invType").value,
    invoice_date: document.getElementById("invDate").value,
    sales_person: document.getElementById("invSalesPerson") ? document.getElementById("invSalesPerson").value.trim() : "SUFIYAN SHAIKH",
    party_name: document.getElementById("invPartyName").value.trim(),
    party_gstin: document.getElementById("invPartyGstin").value.trim(),
    party_address: document.getElementById("invPartyAddress").value.trim(),
    shipping_address: document.getElementById("invPartyAddress").value.trim(),
    party_state: buyerStateName,
    party_state_code: buyerStateCode,
    items: items,
    payment_status: document.getElementById("invPaymentStatus").value,
    amount_paid: parseFloat(document.getElementById("invAmountPaid").value) || 0,
    payment_mode: document.getElementById("invPaymentMode").value,
    notes: document.getElementById("invNotes").value.trim()
  };

  try {
    const res = await fetch("/api/invoices", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      closeNewInvoiceModal();
      await loadSalesInvoices();
      await loadDashboardData();
      alert("Tax Invoice Created Successfully!");
    } else {
      const err = await res.json();
      alert("Error: " + (err.detail || "Failed to create invoice"));
    }
  } catch (err) {
    console.error("Failed to submit invoice", err);
  }
}

// ----------------- PURCHASE BILLS & ITC UPLOAD -----------------
async function loadPurchaseBills() {
  try {
    const res = await fetch("/api/purchases");
    const data = await res.json();
    allPurchases = data.bills || [];
    filterPurchases();
  } catch (err) {
    console.error("Error loading purchase bills", err);
  }
}

function onPurchasesPeriodModeChange() {
  const mode = document.getElementById("purchasesPeriodMode") ? document.getElementById("purchasesPeriodMode").value : "ALL";
  if (document.getElementById("purchasesQuarterWrapper")) document.getElementById("purchasesQuarterWrapper").classList.toggle("hidden", mode !== "QUARTER");
  if (document.getElementById("purchasesMonthWrapper")) document.getElementById("purchasesMonthWrapper").classList.toggle("hidden", mode !== "MONTH");
  if (document.getElementById("purchasesCustomFromWrapper")) document.getElementById("purchasesCustomFromWrapper").classList.toggle("hidden", mode !== "CUSTOM");
  if (document.getElementById("purchasesCustomToWrapper")) document.getElementById("purchasesCustomToWrapper").classList.toggle("hidden", mode !== "CUSTOM");
  filterPurchases();
}

function resetPurchasesFilters() {
  if (document.getElementById("purchasesFyFilter")) document.getElementById("purchasesFyFilter").value = "2025-26";
  if (document.getElementById("purchasesPeriodMode")) document.getElementById("purchasesPeriodMode").value = "ALL";
  if (document.getElementById("purchasesQuarterFilter")) document.getElementById("purchasesQuarterFilter").value = "ALL";
  if (document.getElementById("purchasesMonthFilter")) document.getElementById("purchasesMonthFilter").value = "ALL";
  if (document.getElementById("purchasesDateFrom")) document.getElementById("purchasesDateFrom").value = "";
  if (document.getElementById("purchasesDateTo")) document.getElementById("purchasesDateTo").value = "";
  if (document.getElementById("purchasesItcFilter")) document.getElementById("purchasesItcFilter").value = "ALL";
  if (document.getElementById("purchasesSearchInput")) document.getElementById("purchasesSearchInput").value = "";
  onPurchasesPeriodModeChange();
}

function exportFilteredPurchasesExcel() {
  const fy = document.getElementById("purchasesFyFilter")?.value || "ALL";
  const mode = document.getElementById("purchasesPeriodMode")?.value || "ALL";
  const quarter = document.getElementById("purchasesQuarterFilter")?.value || "ALL";
  const month = document.getElementById("purchasesMonthFilter")?.value || "ALL";
  const fromDate = document.getElementById("purchasesDateFrom")?.value || "";
  const toDate = document.getElementById("purchasesDateTo")?.value || "";

  let url = `/api/reports/purchases/excel?fy=${encodeURIComponent(fy)}`;
  if (mode === "QUARTER" && quarter !== "ALL") url += `&quarter=${encodeURIComponent(quarter)}`;
  if (mode === "MONTH" && month !== "ALL") url += `&month=${encodeURIComponent(month)}`;
  if (mode === "CUSTOM") {
    if (fromDate) url += `&start_date=${encodeURIComponent(fromDate)}`;
    if (toDate) url += `&end_date=${encodeURIComponent(toDate)}`;
  }
  window.location.href = url;
}

function filterPurchases() {
  const fyFilter = document.getElementById("purchasesFyFilter") ? document.getElementById("purchasesFyFilter").value : "ALL";
  const mode = document.getElementById("purchasesPeriodMode") ? document.getElementById("purchasesPeriodMode").value : "ALL";
  const quarterFilter = document.getElementById("purchasesQuarterFilter") ? document.getElementById("purchasesQuarterFilter").value : "ALL";
  const monthFilter = document.getElementById("purchasesMonthFilter") ? document.getElementById("purchasesMonthFilter").value : "ALL";
  const fromDate = document.getElementById("purchasesDateFrom") ? document.getElementById("purchasesDateFrom").value : "";
  const toDate = document.getElementById("purchasesDateTo") ? document.getElementById("purchasesDateTo").value : "";
  const search = document.getElementById("purchasesSearchInput") ? document.getElementById("purchasesSearchInput").value.toLowerCase().trim() : "";
  const itcF = document.getElementById("purchasesItcFilter") ? document.getElementById("purchasesItcFilter").value : "ALL";

  let periodDescription = fyFilter === "ALL" ? "All Financial Years" : `FY ${fyFilter}`;
  if (mode === "QUARTER" && quarterFilter !== "ALL") {
    periodDescription += ` • ${getQuarterLabel(quarterFilter)}`;
  } else if (mode === "MONTH" && monthFilter !== "ALL") {
    periodDescription += ` • ${getMonthName(monthFilter)}`;
  } else if (mode === "CUSTOM" && (fromDate || toDate)) {
    periodDescription += ` • (${fromDate || 'Start'} to ${toDate || 'End'})`;
  }

  const filtered = allPurchases.filter(b => {
    const billDate = b.bill_date || "";
    const billFy = getFinancialYear(billDate);
    const billQ = getQuarter(billDate);
    const billMonth = getMonthCode(billDate);

    // FY Filter
    if (fyFilter !== "ALL" && billFy !== fyFilter) return false;

    // Period Mode Filter
    if (mode === "QUARTER" && quarterFilter !== "ALL") {
      if (billQ !== quarterFilter) return false;
    } else if (mode === "MONTH" && monthFilter !== "ALL") {
      if (billMonth !== monthFilter) return false;
    } else if (mode === "CUSTOM") {
      if (fromDate && billDate < fromDate) return false;
      if (toDate && billDate > toDate) return false;
    }

    // ITC Filter
    if (itcF !== "ALL" && b.itc_eligibility !== itcF) return false;

    // Search Filter
    if (search) {
      const match = (b.bill_number || "").toLowerCase().includes(search) ||
                    (b.vendor_name || "").toLowerCase().includes(search) ||
                    (b.vendor_gstin || "").toLowerCase().includes(search);
      if (!match) return false;
    }

    return true;
  });

  // Calculate CA Summary metrics for the filtered purchases
  let totalTaxable = 0;
  let totalCgst = 0;
  let totalSgst = 0;
  let totalIgst = 0;
  let totalEligibleItc = 0;
  let totalBlockedItc = 0;

  filtered.forEach(b => {
    const taxable = Number(b.taxable_amount || 0);
    const cgst = Number(b.cgst_amount || 0);
    const sgst = Number(b.sgst_amount || 0);
    const igst = Number(b.igst_amount || 0);
    const tax = cgst + sgst + igst;

    totalTaxable += taxable;
    totalCgst += cgst;
    totalSgst += sgst;
    totalIgst += igst;

    if (b.itc_eligibility === "ELIGIBLE") {
      totalEligibleItc += tax;
    } else {
      totalBlockedItc += tax;
    }
  });

  const totalInputTax = totalCgst + totalSgst + totalIgst;

  if (document.getElementById("purchasesSummaryPeriodBadge")) {
    document.getElementById("purchasesSummaryPeriodBadge").innerText = periodDescription;
  }
  if (document.getElementById("purchasesSummaryCount")) {
    document.getElementById("purchasesSummaryCount").innerText = `${filtered.length} Bills`;
  }
  if (document.getElementById("purchasesSummaryTaxable")) {
    document.getElementById("purchasesSummaryTaxable").innerText = `₹ ${totalTaxable.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }
  if (document.getElementById("purchasesSummaryTotalGst")) {
    document.getElementById("purchasesSummaryTotalGst").innerText = `₹ ${totalInputTax.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }
  if (document.getElementById("purchasesSummaryEligibleItc")) {
    document.getElementById("purchasesSummaryEligibleItc").innerText = `₹ ${totalEligibleItc.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }
  if (document.getElementById("purchasesSummaryBlockedItc")) {
    document.getElementById("purchasesSummaryBlockedItc").innerText = `₹ ${totalBlockedItc.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }

  renderPurchaseTable(filtered);
}

function renderPurchaseTable(list) {
  const tbody = document.getElementById("purchaseBillsTbody");
  if (!tbody) return;
  tbody.innerHTML = "";

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="11" class="text-center py-8 text-slate-400">No purchase bills match your selected period or filters</td></tr>`;
    return;
  }

  list.forEach(b => {
    const itcBadge = b.itc_eligibility === "ELIGIBLE"
      ? `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">🟢 Eligible ITC</span>`
      : `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700">🔴 Blocked 17(5)</span>`;

    const totalGst = (b.cgst_amount || 0) + (b.sgst_amount || 0) + (b.igst_amount || 0);
    const billFy = getFinancialYear(b.bill_date);
    const billQ = getQuarter(b.bill_date);

    const docBtn = b.document_file
      ? `<button onclick="viewDocument('${b.document_file}', '${b.vendor_name}')" class="text-sky-600 hover:text-sky-800 font-semibold text-xs flex items-center gap-1 justify-center"><i data-lucide="file-text" class="w-3.5 h-3.5"></i> View Bill</button>`
      : `<span class="text-slate-400 text-[11px]">No File</span>`;

    const tr = document.createElement("tr");
    tr.className = "hover:bg-slate-50/80 transition";
    tr.innerHTML = `
      <td class="py-3 px-4 font-bold text-emerald-700 font-mono">${b.bill_number}</td>
      <td class="py-3 px-4 font-medium text-slate-800">${b.vendor_name}</td>
      <td class="py-3 px-4 font-mono text-[11px] text-slate-500">${b.vendor_gstin || 'Unregistered'}</td>
      <td class="py-3 px-4 text-slate-600">${b.bill_date}</td>
      <td class="py-3 px-4 text-slate-500 font-mono text-[11px]"><span class="font-bold text-slate-700">FY ${billFy}</span> <span class="text-[10px] bg-slate-100 px-1 py-0.5 rounded font-semibold text-slate-600">${billQ}</span></td>
      <td class="py-3 px-4 text-right text-slate-600">₹ ${(b.taxable_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
      <td class="py-3 px-4 text-right font-bold text-emerald-600">₹ ${totalGst.toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
      <td class="py-3 px-4 text-right font-bold text-slate-900">₹ ${(b.total_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
      <td class="py-3 px-4 text-center">${itcBadge}</td>
      <td class="py-3 px-4 text-center">${docBtn}</td>
      <td class="py-3 px-4 text-center">
        <button onclick="deletePurchaseBill(${b.id})" title="Delete Bill" class="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition">
          <i data-lucide="trash-2" class="w-4 h-4"></i>
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  lucide.createIcons();
}

function openUploadBillModal() {
  document.getElementById("uploadBillForm").reset();
  const today = new Date().toISOString().split("T")[0];
  document.getElementById("billDate").value = today;
  document.getElementById("fileChosenLabel").innerText = "Click to upload or drag & drop Supplier Bill (PDF / JPG / PNG)";
  document.getElementById("uploadBillModal").classList.remove("hidden");
  calcBillPreview();
  lucide.createIcons();
}

function closeUploadBillModal() {
  document.getElementById("uploadBillModal").classList.add("hidden");
}

function handleFileChosen(input) {
  if (input.files && input.files[0]) {
    document.getElementById("fileChosenLabel").innerText = `Selected: ${input.files[0].name}`;
  }
}

// When user inputs Total Bill Amount (With GST) -> REVERSE AUTO CALCULATE Taxable Value!
function onBillTotalInput() {
  const total = parseFloat(document.getElementById("billTotalAmount").value) || 0;
  const gstRate = parseFloat(document.getElementById("billGstRate").value) || 0;

  const taxable = total / (1.0 + gstRate / 100.0);
  const taxableInput = document.getElementById("billTaxable");
  if (taxableInput) {
    taxableInput.value = taxable > 0 ? taxable.toFixed(2) : "";
  }
  calcBillPreview();
}

// When user inputs Base Taxable Value (Excl. GST) -> Auto calculate Total Bill Amount!
function onBillTaxableInput() {
  const taxable = parseFloat(document.getElementById("billTaxable").value) || 0;
  const gstRate = parseFloat(document.getElementById("billGstRate").value) || 0;

  const total = taxable * (1.0 + gstRate / 100.0);
  const totalInput = document.getElementById("billTotalAmount");
  if (totalInput) {
    totalInput.value = total > 0 ? total.toFixed(2) : "";
  }
  calcBillPreview();
}

function onBillGstChange() {
  const totalInput = document.getElementById("billTotalAmount");
  const taxableInput = document.getElementById("billTaxable");

  if (document.activeElement === totalInput || (parseFloat(totalInput?.value) > 0 && !document.activeElement?.id?.includes("Taxable"))) {
    onBillTotalInput();
  } else {
    onBillTaxableInput();
  }
}

function calcBillPreview() {
  const taxable = parseFloat(document.getElementById("billTaxable")?.value) || 0;
  const gstRate = parseFloat(document.getElementById("billGstRate")?.value) || 0;
  const isInterstate = document.getElementById("billIsInterstate")?.checked || false;

  const taxAmt = (taxable * gstRate) / 100.0;
  const total = taxable + taxAmt;

  if (document.getElementById("previewBillTaxable")) {
    document.getElementById("previewBillTaxable").innerText = `₹ ${taxable.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }
  if (document.getElementById("previewBillTaxType")) {
    document.getElementById("previewBillTaxType").innerText = isInterstate ? `IGST ${gstRate}%` : `CGST+SGST (${(gstRate/2).toFixed(2)}% each)`;
  }
  if (document.getElementById("previewBillTaxAmt")) {
    document.getElementById("previewBillTaxAmt").innerText = `₹ ${taxAmt.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }
  if (document.getElementById("previewBillTotal")) {
    document.getElementById("previewBillTotal").innerText = `₹ ${total.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }
}

async function handleUploadBillSubmit(e) {
  e.preventDefault();

  const formData = new FormData();
  formData.append("vendor_name", document.getElementById("billVendorName").value.trim());
  formData.append("vendor_gstin", document.getElementById("billVendorGstin").value.trim());
  formData.append("bill_number", document.getElementById("billNumber").value.trim());
  formData.append("bill_date", document.getElementById("billDate").value);
  formData.append("taxable_amount", parseFloat(document.getElementById("billTaxable").value) || 0);
  formData.append("gst_rate", parseFloat(document.getElementById("billGstRate").value) || 18);
  formData.append("is_interstate", document.getElementById("billIsInterstate").checked);
  
  const itcRadio = document.querySelector("input[name='itcEligibility']:checked");
  formData.append("itc_eligibility", itcRadio ? itcRadio.value : "ELIGIBLE");
  formData.append("payment_status", document.getElementById("billPaymentStatus").value);
  formData.append("notes", document.getElementById("billNotes").value.trim());

  const fileInput = document.getElementById("billFileInput");
  if (fileInput.files && fileInput.files[0]) {
    formData.append("file", fileInput.files[0]);
  }

  try {
    const res = await fetch("/api/purchases/upload", {
      method: "POST",
      body: formData
    });

    if (res.ok) {
      closeUploadBillModal();
      await loadPurchaseBills();
      await loadDashboardData();
      alert("Purchase Bill & Input Tax Credit (ITC) recorded successfully!");
    } else {
      const err = await res.json();
      alert("Error: " + (err.detail || "Upload failed"));
    }
  } catch (err) {
    console.error("Failed to upload purchase bill", err);
  }
}

function viewDocument(filename, vendorName) {
  const frame = document.getElementById("docViewerFrame");
  frame.src = `/uploads/${filename}`;
  document.getElementById("docViewerTitle").innerText = `Bill Document - ${vendorName} (${filename})`;
  document.getElementById("viewDocumentModal").classList.remove("hidden");
  lucide.createIcons();
}

function closeDocumentModal() {
  document.getElementById("viewDocumentModal").classList.add("hidden");
  document.getElementById("docViewerFrame").src = "";
}

async function deletePurchaseBill(billId) {
  if (!confirm("Are you sure you want to delete this purchase bill?")) return;
  try {
    await fetch(`/api/purchases/${billId}`, { method: "DELETE" });
    await loadPurchaseBills();
    await loadDashboardData();
  } catch (err) {
    console.error("Error deleting bill", err);
  }
}

// ----------------- CA & TAX FILING REPORTS HUB -----------------
function onReportsPeriodModeChange() {
  const mode = document.getElementById("reportsPeriodMode") ? document.getElementById("reportsPeriodMode").value : "ALL";
  if (document.getElementById("reportsQuarterWrapper")) document.getElementById("reportsQuarterWrapper").classList.toggle("hidden", mode !== "QUARTER");
  if (document.getElementById("reportsMonthWrapper")) document.getElementById("reportsMonthWrapper").classList.toggle("hidden", mode !== "MONTH");
  onReportsPeriodChange();
}

function onReportsPeriodChange() {
  const fy = document.getElementById("reportsFyFilter") ? document.getElementById("reportsFyFilter").value : "ALL";
  const mode = document.getElementById("reportsPeriodMode") ? document.getElementById("reportsPeriodMode").value : "ALL";
  const quarter = document.getElementById("reportsQuarterFilter") ? document.getElementById("reportsQuarterFilter").value : "ALL";
  const month = document.getElementById("reportsMonthFilter") ? document.getElementById("reportsMonthFilter").value : "ALL";

  let query = `?fy=${encodeURIComponent(fy)}`;
  let activeLabel = fy === "ALL" ? "All Financial Years" : `FY ${fy}`;

  if (mode === "QUARTER" && quarter !== "ALL") {
    query += `&quarter=${encodeURIComponent(quarter)}`;
    activeLabel += ` • ${getQuarterLabel(quarter)}`;
  } else if (mode === "MONTH" && month !== "ALL") {
    query += `&month=${encodeURIComponent(month)}`;
    activeLabel += ` • ${getMonthName(month)}`;
  } else {
    activeLabel += " (Annual)";
  }

  if (document.getElementById("reportActivePeriodLabel")) {
    document.getElementById("reportActivePeriodLabel").innerText = activeLabel;
  }

  if (document.getElementById("btnDownloadCaZip")) {
    document.getElementById("btnDownloadCaZip").href = `/api/reports/ca-package/zip${query}`;
  }
  if (document.getElementById("btnDownloadCaMaster")) {
    document.getElementById("btnDownloadCaMaster").href = `/api/reports/ca-master/excel${query}`;
  }
  if (document.getElementById("btnDownloadGstr1")) {
    document.getElementById("btnDownloadGstr1").href = `/api/reports/gstr1/excel${query}`;
  }
  if (document.getElementById("btnDownloadGstr3b")) {
    document.getElementById("btnDownloadGstr3b").href = `/api/reports/gstr3b/excel${query}`;
  }
  if (document.getElementById("btnDownloadSalesRegister")) {
    document.getElementById("btnDownloadSalesRegister").href = `/api/reports/sales/excel${query}`;
  }
  if (document.getElementById("btnDownloadPurchaseRegister")) {
    document.getElementById("btnDownloadPurchaseRegister").href = `/api/reports/purchases/excel${query}`;
  }
}

// ----------------- PARTIES (CUSTOMERS & VENDORS) -----------------
async function loadParties() {
  try {
    const res = await fetch("/api/parties");
    const data = await res.json();
    allParties = data.parties || [];

    const tbody = document.getElementById("partiesTbody");
    if (!tbody) return;
    tbody.innerHTML = "";

    allParties.forEach(p => {
      const tr = document.createElement("tr");
      tr.className = "hover:bg-slate-50 transition";
      tr.innerHTML = `
        <td class="py-3 px-4 font-bold text-slate-800">${p.name}</td>
        <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] font-semibold ${p.type === 'CUSTOMER' ? 'bg-sky-100 text-sky-700' : 'bg-emerald-100 text-emerald-700'}">${p.type}</span></td>
        <td class="py-3 px-4 font-mono text-[11px] text-slate-600">${p.gstin || 'Unregistered'}</td>
        <td class="py-3 px-4 text-slate-600">${p.state} (${p.state_code})</td>
        <td class="py-3 px-4 text-slate-500">${p.phone || ''} ${p.email ? '<br/>' + p.email : ''}</td>
        <td class="py-3 px-4 text-slate-500 truncate max-w-xs">${p.billing_address || '-'}</td>
        <td class="py-3 px-4 text-center">
          <button onclick="deleteParty(${p.id})" class="text-slate-400 hover:text-rose-600 p-1"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    lucide.createIcons();
  } catch (err) {
    console.error("Error loading parties", err);
  }
}

function openNewPartyModal() {
  document.getElementById("newPartyForm").reset();
  document.getElementById("newPartyModal").classList.remove("hidden");
  lucide.createIcons();
}

function closeNewPartyModal() {
  document.getElementById("newPartyModal").classList.add("hidden");
}

function autoDetectPartyState() {
  const gstin = document.getElementById("partyGstinInput").value;
  const code = getStateCodeFromGstin(gstin);
  if (code) {
    const found = stateCodes.find(s => s.code === code);
    if (found) {
      document.getElementById("partyStateInput").value = `${found.code} - ${found.name}`;
    }
  }
}

async function handleCreateParty(e) {
  e.preventDefault();
  const stateVal = document.getElementById("partyStateInput").value;
  const stateCode = stateVal.split(" - ")[0].trim();
  const stateName = stateVal.split(" - ")[1]?.trim() || stateVal;

  const payload = {
    name: document.getElementById("partyNameInput").value.trim(),
    type: document.getElementById("partyTypeInput").value,
    gstin: document.getElementById("partyGstinInput").value.trim(),
    state: stateName,
    state_code: stateCode,
    phone: document.getElementById("partyPhoneInput").value.trim(),
    email: document.getElementById("partyEmailInput").value.trim(),
    billing_address: document.getElementById("partyAddressInput").value.trim()
  };

  try {
    await fetch("/api/parties", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    closeNewPartyModal();
    await loadParties();
  } catch (err) {
    console.error("Error creating party", err);
  }
}

async function deleteParty(partyId) {
  if (!confirm("Are you sure you want to delete this party?")) return;
  try {
    await fetch(`/api/parties/${partyId}`, { method: "DELETE" });
    await loadParties();
  } catch (err) {
    console.error("Error deleting party", err);
  }
}

// ----------------- INVENTORY & ITEMS -----------------
async function loadItems() {
  try {
    const res = await fetch("/api/items");
    const data = await res.json();
    allItems = data.items || [];

    const tbody = document.getElementById("itemsTbody");
    if (!tbody) return;
    tbody.innerHTML = "";

    allItems.forEach(it => {
      const tr = document.createElement("tr");
      tr.className = "hover:bg-slate-50 transition";
      tr.innerHTML = `
        <td class="py-3 px-4 font-bold text-slate-800">${it.name}</td>
        <td class="py-3 px-4 font-mono text-slate-600">${it.hsn_code || '-'}</td>
        <td class="py-3 px-4 text-center">${it.uom}</td>
        <td class="py-3 px-4 text-right font-bold text-slate-900">₹ ${it.selling_price.toFixed(2)}</td>
        <td class="py-3 px-4 text-right text-slate-600">₹ ${it.purchase_price.toFixed(2)}</td>
        <td class="py-3 px-4 text-center font-semibold text-indigo-600">${it.gst_rate}%</td>
        <td class="py-3 px-4 text-center font-bold text-slate-700">${it.stock_quantity}</td>
        <td class="py-3 px-4 text-center">
          <button onclick="deleteItem(${it.id})" class="text-slate-400 hover:text-rose-600 p-1"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    lucide.createIcons();
  } catch (err) {
    console.error("Error loading items", err);
  }
}

function openNewItemModal() {
  document.getElementById("newItemForm").reset();
  document.getElementById("newItemModal").classList.remove("hidden");
  lucide.createIcons();
}

function closeNewItemModal() {
  document.getElementById("newItemModal").classList.add("hidden");
}

async function handleCreateItem(e) {
  e.preventDefault();
  const payload = {
    name: document.getElementById("itemNameInput").value.trim(),
    hsn_code: document.getElementById("itemHsnInput").value.trim(),
    uom: document.getElementById("itemUomInput").value,
    selling_price: parseFloat(document.getElementById("itemSellingPrice").value) || 0,
    gst_rate: parseFloat(document.getElementById("itemGstRate").value) || 18,
    purchase_price: 0,
    stock_quantity: 100
  };

  try {
    await fetch("/api/items", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    closeNewItemModal();
    await loadItems();
  } catch (err) {
    console.error("Error creating item", err);
  }
}

async function deleteItem(itemId) {
  if (!confirm("Are you sure you want to delete this item?")) return;
  try {
    await fetch(`/api/items/${itemId}`, { method: "DELETE" });
    await loadItems();
  } catch (err) {
    console.error("Error deleting item", err);
  }
}

// ----------------- COMPANY SETTINGS -----------------
async function loadCompanySettings() {
  applyUserRolePermissions();
  try {
    const res = await fetch("/api/settings/company");
    const data = await res.json();
    const comp = data.company || {};

    document.getElementById("cfgName").value = comp.name || "";
    document.getElementById("cfgGstin").value = comp.gstin || "";
    document.getElementById("cfgStateCode").value = comp.state_code || "";
    if (comp.state && comp.state_code) {
      document.getElementById("cfgState").value = `${comp.state_code} - ${comp.state}`;
    }
    document.getElementById("cfgAddress").value = comp.address || "";
    document.getElementById("cfgCity").value = comp.city || "";
    document.getElementById("cfgPincode").value = comp.pincode || "";
    document.getElementById("cfgPhone").value = comp.phone || "";
    document.getElementById("cfgEmail").value = comp.email || "";

    document.getElementById("cfgBankName").value = comp.bank_name || "";
    document.getElementById("cfgBankAcc").value = comp.bank_acc || "";
    document.getElementById("cfgBankIfsc").value = comp.bank_ifsc || "";
    document.getElementById("cfgUpiId").value = comp.upi_id || "";
    document.getElementById("cfgPrefix").value = comp.invoice_prefix || "INV-";
    document.getElementById("cfgTerms").value = comp.invoice_terms || "";
  } catch (err) {
    console.error("Error loading settings", err);
  }
}

function autoDetectCompanyState() {
  const gstin = document.getElementById("cfgGstin").value;
  const code = getStateCodeFromGstin(gstin);
  if (code) {
    document.getElementById("cfgStateCode").value = code;
    const found = stateCodes.find(s => s.code === code);
    if (found) {
      document.getElementById("cfgState").value = `${found.code} - ${found.name}`;
    }
  }
}

function syncCompanyStateCode() {
  const stateVal = document.getElementById("cfgState").value;
  const code = stateVal.split(" - ")[0].trim();
  document.getElementById("cfgStateCode").value = code;
}

async function saveCompanySettings(e) {
  e.preventDefault();
  const stateVal = document.getElementById("cfgState").value;
  const stateCode = stateVal.split(" - ")[0].trim();
  const stateName = stateVal.split(" - ")[1]?.trim() || stateVal;

  const payload = {
    name: document.getElementById("cfgName").value.trim(),
    gstin: document.getElementById("cfgGstin").value.trim(),
    state: stateName,
    state_code: stateCode,
    address: document.getElementById("cfgAddress").value.trim(),
    city: document.getElementById("cfgCity").value.trim(),
    pincode: document.getElementById("cfgPincode").value.trim(),
    phone: document.getElementById("cfgPhone").value.trim(),
    email: document.getElementById("cfgEmail").value.trim(),
    bank_name: document.getElementById("cfgBankName").value.trim(),
    bank_acc: document.getElementById("cfgBankAcc").value.trim(),
    bank_ifsc: document.getElementById("cfgBankIfsc").value.trim(),
    upi_id: document.getElementById("cfgUpiId").value.trim(),
    invoice_prefix: document.getElementById("cfgPrefix").value.trim(),
    invoice_terms: document.getElementById("cfgTerms").value.trim()
  };

  try {
    const res = await fetch("/api/settings/company", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      alert("Company Settings Saved Successfully!");
      await loadDashboardData();
    }
  } catch (err) {
    console.error("Error saving company profile", err);
  }
}

// ----------------- SECURITY & SCREEN LOCK ENGINE -----------------
let lockAuthMode = "password"; // 'password' or 'pin'

function initLockClock() {
  updateLockClock();
  setInterval(updateLockClock, 1000);
}

function updateLockClock() {
  const now = new Date();
  const timeEl = document.getElementById("lockLiveTime");
  const dateEl = document.getElementById("lockLiveDate");
  if (timeEl) {
    timeEl.innerText = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
  }
  if (dateEl) {
    dateEl.innerText = now.toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  }
}

function setLockAuthMode(mode) {
  lockAuthMode = mode;
  const passInputs = document.getElementById("lockPasswordInputs");
  const pinInputs = document.getElementById("lockPinInputs");
  const btnPass = document.getElementById("btnAuthModePass");
  const btnPin = document.getElementById("btnAuthModePin");
  const errorBox = document.getElementById("lockErrorMsg");
  if (errorBox) errorBox.classList.add("hidden");

  if (mode === "password") {
    if (passInputs) passInputs.classList.remove("hidden");
    if (pinInputs) pinInputs.classList.add("hidden");
    if (btnPass) btnPass.className = "flex-1 py-1.5 rounded-lg text-xs font-semibold text-white bg-sky-600/30 border border-sky-500/40 transition";
    if (btnPin) btnPin.className = "flex-1 py-1.5 rounded-lg text-xs font-semibold text-slate-400 hover:text-white transition";
    const passField = document.getElementById("lockPassword");
    if (passField) passField.focus();
  } else {
    if (passInputs) passInputs.classList.add("hidden");
    if (pinInputs) pinInputs.classList.remove("hidden");
    if (btnPin) btnPin.className = "flex-1 py-1.5 rounded-lg text-xs font-semibold text-white bg-indigo-600/30 border border-indigo-500/40 transition";
    if (btnPass) btnPass.className = "flex-1 py-1.5 rounded-lg text-xs font-semibold text-slate-400 hover:text-white transition";
    const pinField = document.getElementById("lockPinInput");
    if (pinField) pinField.focus();
  }
  lucide.createIcons();
}

function togglePasswordVisibility(fieldId) {
  const input = document.getElementById(fieldId);
  if (!input) return;
  input.type = input.type === "password" ? "text" : "password";
}

function lockScreen() {
  const modal = document.getElementById("screenLockModal");
  if (modal) {
    modal.classList.remove("hidden");
    modal.style.display = "flex";
    modal.style.opacity = "1";
  }
  const passField = document.getElementById("lockPassword");
  if (passField) {
    passField.value = "";
    passField.focus();
  }
  const pinField = document.getElementById("lockPinInput");
  if (pinField) pinField.value = "";
  const errorBox = document.getElementById("lockErrorMsg");
  if (errorBox) errorBox.classList.add("hidden");
  lucide.createIcons();
}

async function handleUnlockSubmit(e) {
  e.preventDefault();
  const errorBox = document.getElementById("lockErrorMsg");
  const errorText = document.getElementById("lockErrorText");
  const btnUnlock = document.getElementById("btnUnlockApp");

  const username = document.getElementById("lockUsername")?.value.trim() || "admin";
  const password = document.getElementById("lockPassword")?.value || "";
  const pin = document.getElementById("lockPinInput")?.value.trim() || "";

  const payload = (lockAuthMode === "pin")
    ? { pin_code: pin }
    : { username: username, password: password };

  if (lockAuthMode === "pin" && !pin) {
    if (errorBox && errorText) {
      errorText.innerText = "Please enter your 4-digit PIN code.";
      errorBox.classList.remove("hidden");
    }
    return;
  }

  if (lockAuthMode === "password" && !password) {
    if (errorBox && errorText) {
      errorText.innerText = "Please enter your login password.";
      errorBox.classList.remove("hidden");
    }
    return;
  }

  try {
    if (btnUnlock) {
      btnUnlock.disabled = true;
      btnUnlock.innerHTML = `<span class="inline-block animate-spin mr-2">⏳</span> Verifying Credentials...`;
    }

    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      const data = await res.json();
      currentUserRole = data.role || "ADMIN";
      currentUsername = data.username || "admin";
      currentUserDisplayName = data.display_name || "Business Owner / Admin";

      applyUserRolePermissions();

      if (errorBox) errorBox.classList.add("hidden");
      
      const modal = document.getElementById("screenLockModal");
      if (modal) {
        modal.style.opacity = "0";
        setTimeout(() => {
          modal.classList.add("hidden");
          modal.style.display = "none";
          modal.style.opacity = "1";
        }, 250);
      }
    } else {
      const errData = await res.json().catch(() => ({}));
      if (errorBox && errorText) {
        errorText.innerText = errData.detail || "Invalid Username, Password, or PIN code.";
        errorBox.classList.remove("hidden");
      }
    }
  } catch (err) {
    console.error("Authentication error", err);
    if (errorBox && errorText) {
      errorText.innerText = "Network connection error. Please try again.";
      errorBox.classList.remove("hidden");
    }
  } finally {
    if (btnUnlock) {
      btnUnlock.disabled = false;
      btnUnlock.innerHTML = `<i data-lucide="unlock" class="w-4 h-4"></i> Unlock Application`;
      lucide.createIcons();
    }
  }
}

function applyUserRolePermissions() {
  const topUserBadge = document.getElementById("topUserBadge");
  const topUserBadgeText = document.getElementById("topUserBadgeText");
  const sidebarUserBadge = document.getElementById("sidebarUserBadge");
  const sidebarUsername = document.getElementById("sidebarUsername");

  if (currentUserRole === "CA") {
    // 1. Top Header Badge
    if (topUserBadge) {
      topUserBadge.className = "flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-semibold";
      topUserBadge.innerHTML = `<span class="w-2 h-2 rounded-full bg-emerald-500"></span><span id="topUserBadgeText">📊 CA / Auditor</span>`;
    }
    // 2. Sidebar Badge
    if (sidebarUserBadge) {
      sidebarUserBadge.className = "font-bold text-emerald-400 flex items-center gap-1";
      sidebarUserBadge.innerText = "📊 CA / Auditor";
    }
    if (sidebarUsername) {
      sidebarUsername.innerText = currentUsername || "ca_audit";
    }

    // 3. Settings Tab Cards (Hide Security Management, Show Restricted Banner)
    document.getElementById("caRestrictedBanner")?.classList.remove("hidden");
    document.getElementById("adminSecurityCard")?.classList.add("hidden");
    document.getElementById("caCredentialsCard")?.classList.add("hidden");
  } else {
    // ADMIN (Owner)
    // 1. Top Header Badge
    if (topUserBadge) {
      topUserBadge.className = "flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold";
      topUserBadge.innerHTML = `<span class="w-2 h-2 rounded-full bg-indigo-500"></span><span id="topUserBadgeText">👑 Admin (Owner)</span>`;
    }
    // 2. Sidebar Badge
    if (sidebarUserBadge) {
      sidebarUserBadge.className = "font-bold text-sky-400 flex items-center gap-1";
      sidebarUserBadge.innerText = "👑 Admin";
    }
    if (sidebarUsername) {
      sidebarUsername.innerText = currentUsername || "admin";
    }

    // 3. Settings Tab Cards (Show Full Security & CA Management)
    document.getElementById("caRestrictedBanner")?.classList.add("hidden");
    document.getElementById("adminSecurityCard")?.classList.remove("hidden");
    document.getElementById("caCredentialsCard")?.classList.remove("hidden");
    loadCaInfo();
  }

  lucide.createIcons();
}

async function loadCaInfo() {
  try {
    const res = await fetch("/api/auth/ca-credentials-info");
    if (res.ok) {
      const data = await res.json();
      const caUserInput = document.getElementById("caSetUsername");
      if (caUserInput && data.ca_username) {
        caUserInput.value = data.ca_username;
      }
    }
  } catch (err) {
    console.error("Error loading CA info", err);
  }
}

async function saveSecurityCredentials(e) {
  e.preventDefault();
  const currentPass = document.getElementById("secCurrentPassword").value;
  const newUsername = document.getElementById("secNewUsername").value.trim();
  const newPassword = document.getElementById("secNewPassword").value;
  const newPin = document.getElementById("secNewPin").value.trim();
  const msgEl = document.getElementById("secSettingsMsg");

  if (!currentPass) {
    alert("Please enter current password to verify authorization.");
    return;
  }

  try {
    const res = await fetch("/api/auth/change-credentials", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        current_password: currentPass,
        new_username: newUsername || null,
        new_password: newPassword || null,
        new_pin: newPin || null
      })
    });

    const data = await res.json();
    if (res.ok) {
      if (msgEl) {
        msgEl.className = "p-3 rounded-lg text-xs font-semibold bg-emerald-50 border border-emerald-200 text-emerald-800";
        msgEl.innerText = "Admin security credentials updated successfully!";
        msgEl.classList.remove("hidden");
      }
      document.getElementById("secCurrentPassword").value = "";
      document.getElementById("secNewPassword").value = "";
      document.getElementById("secNewPin").value = "";
      if (newUsername) {
        currentUsername = newUsername;
        document.getElementById("lockUsername").value = newUsername;
        applyUserRolePermissions();
      }
    } else {
      if (msgEl) {
        msgEl.className = "p-3 rounded-lg text-xs font-semibold bg-rose-50 border border-rose-200 text-rose-800";
        msgEl.innerText = data.detail || "Failed to update security credentials.";
        msgEl.classList.remove("hidden");
      }
    }
  } catch (err) {
    console.error("Error updating credentials", err);
    if (msgEl) {
      msgEl.className = "p-3 rounded-lg text-xs font-semibold bg-rose-50 border border-rose-200 text-rose-800";
      msgEl.innerText = "Connection error. Please try again.";
      msgEl.classList.remove("hidden");
    }
  }
}

async function saveCaCredentials(e) {
  e.preventDefault();
  const adminPass = document.getElementById("caAdminAuthPassword")?.value || "";
  const caUser = document.getElementById("caSetUsername")?.value.trim() || "ca_audit";
  const caPass = document.getElementById("caSetPassword")?.value || "";
  const caPin = document.getElementById("caSetPin")?.value.trim() || "";
  const msgEl = document.getElementById("caSettingsMsg");

  if (!adminPass) {
    alert("Please enter Admin Password to authorize changes to the CA account.");
    return;
  }

  try {
    const res = await fetch("/api/auth/manage-ca", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        admin_password: adminPass,
        ca_username: caUser,
        ca_password: caPass || null,
        ca_pin: caPin || null
      })
    });

    const data = await res.json();
    if (res.ok) {
      if (msgEl) {
        msgEl.className = "p-3 rounded-lg text-xs font-semibold bg-emerald-50 border border-emerald-200 text-emerald-800";
        msgEl.innerText = data.message || "CA credentials updated successfully!";
        msgEl.classList.remove("hidden");
      }
      document.getElementById("caAdminAuthPassword").value = "";
      document.getElementById("caSetPassword").value = "";
      document.getElementById("caSetPin").value = "";
    } else {
      if (msgEl) {
        msgEl.className = "p-3 rounded-lg text-xs font-semibold bg-rose-50 border border-rose-200 text-rose-800";
        msgEl.innerText = data.detail || "Failed to update CA credentials.";
        msgEl.classList.remove("hidden");
      }
    }
  } catch (err) {
    console.error("Error updating CA credentials", err);
    if (msgEl) {
      msgEl.className = "p-3 rounded-lg text-xs font-semibold bg-rose-50 border border-rose-200 text-rose-800";
      msgEl.innerText = "Connection error. Please try again.";
      msgEl.classList.remove("hidden");
    }
  }
}
